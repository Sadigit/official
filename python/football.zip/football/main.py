import pygame 
import data
from data import *
pygame.init()
##############
##############
font = pygame.font.SysFont("arial",33)
font2 = pygame.font.SysFont("arial",23)
screen = pygame.display.set_mode((700,500))
text3 = font2.render("SPEED ",None,(255,255,255))

pygame.display.set_caption("F O O T  B A L L")
class player:
	def __init__(self,x,y,x_vel,move):
		self.x=x
		self.y=y
		self.x_vel=x_vel
		self.move=move

p_red= player(120,370,0,2.5)
p_blue= player(530,370,0,2.5)


def test():
	global bx,by,p_red,p_blue,r_rect,b_rect,ball_rect,left_jump,right_jump,rj,lj,b_move
	if right_jump:
		by-=rj
		rj-=1
		bx+=b_move
		if rj < -22:
			right_jump=False
			rj=22
	if left_jump:
		by-=lj
		lj-=1
		bx-=b_move
		if lj < -22:
			left_jump=False
			lj=22

	if r_rect.colliderect(ball_rect):
		if (r_rect.right - ball_rect.left) > 0 and (r_rect.right - ball_rect.left) < 10:
			right_jump=True
		if bx >325:
			if (r_rect.left - ball_rect.right) < 0 and (r_rect.left - ball_rect.right) >-10:
				left_jump=True
	if b_rect.colliderect(ball_rect):
		if bx < 325:

			if (b_rect.right - ball_rect.left) > 0 and (b_rect.right - ball_rect.left) < 10:
				right_jump=True
		if (b_rect.left - ball_rect.right) < 0 and (b_rect.left - ball_rect.right) >-10:
			left_jump=True


## loop
run= True
while run:
	screen.blit(bg,(0,0))
	pygame.draw.rect(screen,(24,24,24),(240,40,220,150))
	pygame.draw.rect(screen,(255,0,0),(80,470,r_power,10))
	pygame.draw.rect(screen,(0,0,255),(480,470,b_power,10))

	
	r_rect=pygame.Rect(p_red.x,p_red.y,32,48)
	b_rect=pygame.Rect(p_blue.x,p_blue.y,32,48)
	ball_rect=pygame.Rect(bx,by,32,32)
	r_post=pygame.Rect(0,300,118,175)
	b_post=pygame.Rect(580,300,118,175)
	# pygame.draw.rect(screen,(255,0,0),r_post,3)
	# pygame.draw.rect(screen,(255,0,0),b_post,3)

	screen.blit(red[rc],(p_red.x,p_red.y))
	screen.blit(blue[bc],(p_blue.x,p_blue.y))
	screen.blit(ball,(bx,by))
	test()
	if ball_rect.colliderect(r_post):
		bx=325
		b_score+=1
	if ball_rect.colliderect(b_post):
		bx=325
		r_score+=1
	text = font.render(f"RED : {r_score} ",None,(255,255,255))
	text2 = font.render(f"BLUE : {b_score} ",None,(255,255,255))
	screen.blit(text,(299,70))
	screen.blit(text2,(299,130))
	screen.blit(text3,(99,440))
	screen.blit(text3,(499,440))
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run =False

		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_a:
				rc=1
				p_red.x_vel-=p_red.move
			if event.key == pygame.K_d:
				rc=0
				p_red.x_vel+=p_red.move

			if event.key == pygame.K_LEFT:
				bc=0
				p_blue.x_vel-=p_blue.move
			if event.key == pygame.K_RIGHT:
				bc=1
				p_blue.x_vel+=p_blue.move


			if event.key == pygame.K_SPACE:
				if r_power == 100:
					r_power=1
					p_red.move=3.5
			if event.key == pygame.K_UP:

				if b_power == 100:
					b_power=1
					p_blue.move=3.5



		if event.type == pygame.KEYUP:
			if event.key == pygame.K_a:
				p_red.x_vel=0
			if event.key == pygame.K_d:
				p_red.x_vel=0

			if event.key == pygame.K_LEFT:
				p_blue.x_vel=0
			if event.key == pygame.K_RIGHT:
				p_blue.x_vel=0




	p_red.x+=p_red.x_vel
	p_blue.x+=p_blue.x_vel
	if p_red.x < 120:
		p_red.x = 120
	if p_red.x > 500:
		p_red.x = 500
	if p_blue.x < 120:
		p_blue.x = 120
	if p_blue.x > 500:
		p_blue.x = 500

	r_power+=2
	b_power+=2

	if int(r_power) > 100:
		r_power=100
	else:
		p_red.move=2.5
	if int(b_power) > 100:
		b_power=100
	else:
		p_blue.move=2.5
	print(p_red.move)


	pygame.display.flip()

