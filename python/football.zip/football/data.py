import pygame
###### img #######
rc=0
bc=0
bg = pygame.image.load("bg.png")
red=[pygame.image.load("rr.png"),pygame.image.load("rl.png")]
blue=[pygame.image.load("bl.png"),pygame.image.load("br.png")]
ball = pygame.image.load("ball.png")
left_jump=False
right_jump=False
rj=22
lj=22
bx=325
by=370
b_move=2.5
r_score=0
b_score=0
r_power=100
b_power=100
