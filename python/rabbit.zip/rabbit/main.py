import pygame
import data
from data import *
pygame.init()
#####################
# font
font = pygame.font.SysFont("arial",49)
#####
#screen
screen = pygame.display.set_mode((480,480),pygame.RESIZABLE,pygame.SCALED)
pygame.display.set_caption("R A B B I T")#title
# fps 
clock = pygame.time.Clock()

#### trnsformation ####
stand_img = pygame.transform.scale(stand_img,(48,48))
p_right[0] = pygame.transform.scale(p_right[0],(48,48))
p_right[1] = pygame.transform.scale(p_right[1],(48,48))
p_right[2] = pygame.transform.scale(p_right[2],(48,48))
p_right[3] = pygame.transform.scale(p_right[3],(48,48))
p_right[4] = pygame.transform.scale(p_right[4],(48,48))

bg = pygame.transform.scale(bg,(1280,800))

p_left[0] = pygame.transform.scale(p_left[0],(48,48))
p_left[1] = pygame.transform.scale(p_left[1],(48,48))
p_left[2] = pygame.transform.scale(p_left[2],(48,48))
p_left[3] = pygame.transform.scale(p_left[3],(48,48))
p_left[4] = pygame.transform.scale(p_left[4],(48,48))
##### eat ###
def eat(rect):
	global c_collect, drawing,drawing2,drawing3,tx
	p_r = pygame.Rect(x, y, 48, 48)
	if p_r.colliderect(rect):
		c_collect+=1
		drawing=False
def eat2(rect):
	global c_collect, drawing,drawing2,drawing3,tx
	p_r = pygame.Rect(x, y, 48, 48)
	if p_r.colliderect(rect):
		c_collect+=1
		drawing2=False
def eat3(rect):
	global c_collect, drawing,drawing2,drawing3,tx
	p_r = pygame.Rect(x, y, 48, 48)
	if p_r.colliderect(rect):
		c_collect+=1
		drawing3=False



#### test ##
def test(rect):
	global p_r,x,y,g,txm,move,x_vel,ex,ey,emove,ex_vel
	p_r = pygame.Rect(x, y, 48, 48)
	e_r = pygame.Rect(ex, ey, 48, 48)
	keys = pygame.key.get_pressed()


	if p_r.colliderect(rect):


		if int(rect.top - p_r.bottom) < 1 and int(rect.top - p_r.bottom)  >-10:
			y-=g*3+5
		if keys[pygame.K_a]:
			if int(rect.right - p_r.left) > 0 and int(rect.right - p_r.left) <3:
				x+=move
				x_vel-=move

		if keys[pygame.K_d]:
			if int(rect.left - p_r.right) < 0 and int(rect.left - p_r.right) >-3:
				x-=move
				x_vel+=move

	
	else:g=2.5
def test2(rect):
	global p_r,x,y,g,txm,move,ex_vel,ex,ey,emove,ejump,ejh,x,y
	if ejump: # jumping

		ey-=ejh
		ejh-=1
		if ejh < -12:
			ejh=20                                                #
			ejump=False
	keys = pygame.key.get_pressed()

	e_r = pygame.Rect(ex, ey, 48, 48)

	if e_r.colliderect(rect):


		if int(rect.top - e_r.bottom) < 1 and int(rect.top - e_r.bottom)  >-10:
			ey-=eg*3

		if int(rect.right - e_r.left) > 0 and int(rect.right - e_r.left) <2:
			ejump=True



		if int(rect.left - e_r.right) < 0 and int(rect.left - e_r.right) >-2:
			ejump=True

		if y > ey+48:
			ejump=True




#tile map######
def tiles():
	global map_now,lvl1,txm,x_vel,x,y,g,drawing,drawing2,drawing3,c_collect,hp,ex
	tx=txm
	ty=0
	for row in map_now:
		for col in row:
			if col == "w":


				trect = pygame.Rect(tx,ty,48,48)
				test2(trect)
				test(trect)


				screen.blit(main_tile,(tx,ty))

			if col == "d":
				trect = pygame.Rect(tx,ty,48,48)


				screen.blit(main_tile2,(tx,ty))
				# pygame.draw.rect(screen,(255,255,255),trect,3)

				test(trect)
				test2(trect)
			if col == "o":
				if drawing:
					trect = pygame.Rect(tx,ty,48,48)
					screen.blit(carrots,(tx,ty))
					eat(trect)
			if col == "t":
				if drawing2:
					trect = pygame.Rect(tx,ty,48,48)
					screen.blit(carrots,(tx,ty))
					eat2(trect)
			if col == "h":
				if drawing3:
					trect = pygame.Rect(tx,ty,48,48)
					screen.blit(carrots,(tx,ty))
					eat3(trect)

			if hp <=0 or y > 480:
				txm=0
				hp=100
				ex=100
				c_collect=0
				drawing=True
				drawing2=True
				drawing3=True
				y=380
				ex=100



			tx+=48
		ty+=48
		tx=txm
	if c_collect >=3:


		drawing=True
		drawing2=True
		drawing3=True
		c_collect=0
		txm=0
		ex=100
		if map_now == lvl1:
			map_now = lvl2
		






#loop
run = True
while run:
	text = font.render(f"{c_collect} / 3",False,(255,200,0))

	screen.blit(bg,(0,0))
	pygame.draw.rect(screen,(255,0,0),(200,40,100,20))
	pygame.draw.rect(screen,(255,255,0),(200,40,int(hp),20))

	screen.blit(c_icon,(20,26))
	screen.blit(text,(70,26))
	clock.tick(30)

	tiles()

#################################################################
	e_r = pygame.Rect(ex, ey, 48, 48)
	p_r = pygame.Rect(x+7, y, 34, 48)
	screen.blit(enemy_img,(ex,ey))
	# pygame.draw.rect(screen,(255,255,255),e_r,3)


	# stand pic                                                 #
	if std:                                                     #
		screen.blit(stand_img, (x,y))                           #

	if right ==True and left == False:####  right animation
		r_c+=0.20
		screen.blit(p_right[int(r_c)],(x,y))
		if int(r_c) >=4:
			r_c=0
	if left ==True and right == False:####  right animation
		l_c+=0.20
		screen.blit(p_left[int(l_c)],(x,y))                    #
		if int(l_c) >=4:                                       #
			l_c=0     


	if jump: # jumping
		pygame.time.delay(10)
		y-=jh
		jh-=1
		if jh < -12:
			jh=20                                                #
			jump=False
################################################################



	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run =False
##########       key down
		if event.type == pygame.KEYDOWN:

			if event.key == pygame.K_d:
				ex_vel-=emove
				right=True
				left=False
				std=False
				x_vel-=move
			if event.key == pygame.K_a:
				ex_vel+=emove

				x_vel+=move
				std=False
				left=True
				right=False
			if event.key == pygame.K_SPACE:
				jump=True

######         key up
		if event.type == pygame.KEYUP:

			if event.key == pygame.K_d or  event.key == pygame.K_a:
				x_vel=0
				std=True
			if event.key == pygame.K_d:
				ex_vel=0
				right=False
				left=False
				std=True
			if event.key == pygame.K_a:
				ex_vel=0

				std=True
				left=False
				right=False



	txm+=x_vel
	y+=g
	ey+=eg
	ex+=ex_vel
	if x-40 > ex:
		ex+=0.91
	if x+40 < ex:
		ex-=0.91
	if p_r.colliderect(e_r):
		hp-=0.90
	
	if ex == x and ey > y:
		ex-=20
	pygame.display.flip()


