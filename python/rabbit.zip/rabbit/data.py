import pygame

# images#######
bg = pygame.image.load("assets/pic/bg.jpeg")
enemy_img= pygame.image.load("assets/pic/e.png")

p_right = [pygame.image.load("assets/pic/1.png"),pygame.image.load("assets/pic/2.png"),pygame.image.load("assets/pic/3.png"),pygame.image.load("assets/pic/4.png"),pygame.image.load("assets/pic/5.png")]

stand_img =pygame.image.load("assets/pic/Pink_Monster.png")

p_left = [pygame.image.load("assets/pic/l1.png"),pygame.image.load("assets/pic/l2.png"),pygame.image.load("assets/pic/l3.png"),pygame.image.load("assets/pic/l4.png"),pygame.image.load("assets/pic/l5.png")]

main_tile = pygame.image.load("assets/pic/tile28.png")
main_tile2 = pygame.image.load("assets/pic/tile122.png")
c_icon = pygame.image.load("assets/pic/c.png")
carrots = pygame.image.load("assets/pic/cd.png")
#####################
#### enemy ######
ex = 100
ey= 380
eg=2
ex_vel=0
emove=2
ejump = False
ejh=20


## bool##
std = True

right=False

left = False

jump = False

drawing= True
drawing2= True
drawing3= True


### player #
hp=100
x=(480+(48/2))/2
y= 380
x_vel=0
l_c=0
r_c=0
g=1
move=2
jh=20
c_collect=0
####### maps ######
txm=0
t=txm

lvl1=[
"",
"",
"",
"w",
"d",
"d             t",
"d         o ddd",
"d        dd          h",
"d       w      ww    w",
"wwwwwwwwwwwwwwwwwwwwwwwwww",

]
lvl2=[
"",
"",
"",
"        h",
"        w      ",
"w   www      t",
"  o   dd     w",
"  w  d    w    ",
"  dww    w     ",
"wwwwwwwwwwwwwwwwwww",
]
map_now = lvl1
