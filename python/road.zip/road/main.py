import pygame
from random import randint as rd
pygame.init()
screen = pygame.display.set_mode((500,700))

class info:
	def __init__(self ,x ,y):
		self.x = x
		self.y = y
car1 = info(190,480)
car2 = info(rd(0,400),-140)
bg = info(-5, -265)
x_change =0
car1_img = pygame.image.load("car11.png")
car2_img = pygame.image.load("car2.png")
bg_img = pygame.image.load("bg.jpeg")
bg_move=0.99
car2_move=4
car1_move = 2
run = True
while run:
	rect1 = pygame.draw.rect(screen,(255,255,255),(car1.x, car1.y, 99, 165,))
	rect2 = pygame.draw.rect(screen,(255,255,255),(car2.x, car2.y, 99, 165,))
	screen.blit(bg_img, (bg.x,bg.y))
	screen.blit(car1_img, (car1.x, car1.y))
	

	screen.blit(car2_img, (car2.x, car2.y))


	screen.blit(car1_img, (car1.x, car1.y))
	car2.y+=car2_move
	bg.y+=bg_move
	bg_move+=1

	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run = False
		if event.type == pygame.KEYDOWN: 
			if event.key == pygame.K_a:
				x_change -= car1_move
			if event.key == pygame.K_d:
				x_change += car1_move
			if event.key == pygame.K_r:
				car1_move=2
				car2_move=4
				bg_move=0.99
				car1.x=190
				car1.y= 480
				car2.x = rd(0, 400)
				car2.y = -140
		if event.type == pygame.KEYUP:
			if event.key == pygame.K_a:
				x_change = 0
			if event.key == pygame.K_d:
				x_change = 0 

	car1.x += x_change 
	if int(bg.y) == 0:
		bg.y = -268
	if int(car2.y) >= 710:
		car2.x=rd(0,400)
		car2.y= -140
	if int(car1.x) <= 0:
		car1.x = 0
	if int(car1.x) >= 399:
		car1.x = 399
	if rect1.colliderect(rect2):
		car1_move=0
		car2_move=0
		bg_move=0
	else:
		car1_move=2
		car2_move=4
		bg_move=0.99
	pygame.display.update()