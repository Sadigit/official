import pygame 
from random import randint as rd
from pygame.locals import *
pygame.init()
screen = pygame.display.set_mode((1000,700))
bg = pygame.image.load("bg.png").convert()
scope = pygame.image.load("s.png")
zomb = pygame.image.load("zomb.png")
zx=rd(0,900)
zy=rd(10,500)
scoreis=0
font = pygame.font.SysFont('comicsans', 60,True)
run = True
while run:
	mx , my = pygame.mouse.get_pos()
	rect1 = pygame.draw.rect(screen,(255,255,255),(zx+20,zy+10,150,258),5)
	rect2 = pygame.draw.rect(screen,(255,255,255),(mx-25,my-25,50,50),5)
	screen.blit(bg, (-450,-100))
	text = font.render(f'Score:{scoreis}',True,(255,255,255),(0,0,100))
	screen.blit(text, (430,5))
	screen.blit(zomb , (zx,zy))
	screen.blit(scope ,(mx-85,my-85))
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run = False   
		if event.type == MOUSEBUTTONDOWN:
			if rect2.colliderect(rect1) and event.button == 1:
				scoreis+=1
				zx=rd(0,900)
				zy=rd(10,500)
	pygame.display.update()